# mypackage
This library was created on how to publish your own python package

# how to install 

